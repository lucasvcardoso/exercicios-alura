﻿Module Module1

    Sub Main()
        Dim x As Integer = 1
        Dim y As Integer = 2
        Dim z As Integer = 0

        z = x + y
        Console.WriteLine(z)

    End Sub

End Module
