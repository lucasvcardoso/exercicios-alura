﻿Public Class Frm_TelaPrincipal
    Private Sub Btm_Principal_Click(sender As Object, e As EventArgs) Handles Btm_Principal.Click

        MsgBox("Olá Mundo !!!", MsgBoxStyle.Critical, "Mensagem")


    End Sub
End Class
